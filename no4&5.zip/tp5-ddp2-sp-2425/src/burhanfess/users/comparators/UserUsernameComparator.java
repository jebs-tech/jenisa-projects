package burhanfess.users.comparators;

import burhanfess.users.User;
import java.util.Comparator;

public class UserUsernameComparator implements Comparator<User> {

    @Override
    public int compare(User user, User other) {
        return user.getUsername().compareTo(other.getUsername());
    }
    
}
