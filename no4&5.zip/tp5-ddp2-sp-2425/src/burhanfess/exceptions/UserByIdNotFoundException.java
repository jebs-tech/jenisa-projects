package burhanfess.exceptions;

public class UserByIdNotFoundException extends Exception {

    public UserByIdNotFoundException(int id) {
        super(String.format("User dengan ID %d tidak ditemukan", id));
    }
    
}
