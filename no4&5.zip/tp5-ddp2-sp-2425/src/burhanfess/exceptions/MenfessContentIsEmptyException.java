package burhanfess.exceptions;

public class MenfessContentIsEmptyException extends Exception {
    
    public MenfessContentIsEmptyException() {
        super("Isi menfess tidak boleh kosong.");
    }

}
