package burhanfess.exceptions;

public class MenfessByIdNotFoundException extends Exception {
    
    public MenfessByIdNotFoundException(int menfessId) {
        super(String.format("Menfess dengan ID %d tidak ditemukan", menfessId));
    }
    
}
