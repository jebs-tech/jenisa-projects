package burhanfess.exceptions;

public class UsernameContainsWhitespaceException extends Exception {
    
    public UsernameContainsWhitespaceException() {
        super("Tidak boleh ada spasi di dalam username.");
    }
}