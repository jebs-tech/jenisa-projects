package burhanfess.exceptions;

public class UserByUsernameNotFoundException extends Exception {

    public UserByUsernameNotFoundException(String username) {
        super(String.format("User dengan username '%s' tidak ditemukan", username));
    }
    
}