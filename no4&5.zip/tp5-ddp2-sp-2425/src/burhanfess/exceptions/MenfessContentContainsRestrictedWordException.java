package burhanfess.exceptions;

public class MenfessContentContainsRestrictedWordException extends Exception {
    
    public MenfessContentContainsRestrictedWordException(String word) {
        super(String.format("Menfess gagal dikirim karena terdapat kata yang dibatasi: '%s'", word));
    }
    

}
