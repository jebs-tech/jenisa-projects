package burhanfess.exceptions;

public class WordAlreadyExistsException extends Exception {

    public WordAlreadyExistsException(String word) {
        super(String.format("Kata '%s' sudah ada di dalam daftar kata yang dibatasi", word));
    }
    
}
