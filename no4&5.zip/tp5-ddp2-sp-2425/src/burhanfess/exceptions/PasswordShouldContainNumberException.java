package burhanfess.exceptions;

public class PasswordShouldContainNumberException extends Exception {

    public PasswordShouldContainNumberException() {
        super("Password harus mengandung setidaknya satu angka.");
    }
    
}
