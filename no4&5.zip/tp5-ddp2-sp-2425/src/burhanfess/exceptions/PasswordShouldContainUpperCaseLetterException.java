package burhanfess.exceptions;

public class PasswordShouldContainUpperCaseLetterException extends Exception {

    public PasswordShouldContainUpperCaseLetterException() {
        super("Password harus mengandung setidaknya satu huruf kapital.");
    }

}
