package burhanfess.exceptions;

public class InvalidInputException extends Exception {
    
    public InvalidInputException() {
        super("Input tidak valid. Silakan coba lagi.");
    }
}
