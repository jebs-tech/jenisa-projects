package burhanfess.exceptions;

public class PasswordLengthTooShortException extends Exception {

    public PasswordLengthTooShortException() {
        super("Panjang password minimal 8 karakter.");
    }
    
}
