package burhanfess.logs;

@FunctionalInterface
public interface LogFilter {
    boolean filter(String log);
}