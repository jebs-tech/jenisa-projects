package burhanfess.logs;

public class LogFilterImpl implements LogFilter {

    @Override
    public boolean filter(String log) {
        return log.contains("admin");
    }
}
