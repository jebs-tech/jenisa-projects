package burhanfess.logs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LogService {
    List<String> barisLog;

    public LogService(){
        barisLog = new ArrayList<String>();
    }

    public void readFile(String namaFile) throws FileNotFoundException {
        try(BufferedReader br = new BufferedReader(new FileReader(namaFile))){
            while(true){
                String baris = br.readLine();
                if(baris == null){
                    return;
                } else {
                    barisLog.add(baris);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void filterLog(LogFilter logFilter){
        barisLog.stream()
                .filter(logFilter::filter)
                .forEach(System.out::println);
    }
}