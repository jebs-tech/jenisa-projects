package burhanfess.services;

import java.util.List;

import burhanfess.BurhanFess;
import burhanfess.displays.UnauthorizedDisplay;
import burhanfess.exceptions.MenfessContentContainsRestrictedWordException;
import burhanfess.exceptions.MenfessContentIsEmptyException;
import burhanfess.exceptions.MenfessContentIsTooLongException;
import burhanfess.exceptions.PasswordDoesNotChangeException;
import burhanfess.exceptions.UserByUsernameNotFoundException;
import burhanfess.menfess.*;
import burhanfess.repositories.*;
import burhanfess.users.Cosmic;
import burhanfess.users.User;

public class CosmicServiceImpl implements CosmicService {

    private Cosmic cosmic;
    private MenfessRepository menfessRepository;
    private UserRepository userRepository;
    private RestrictedWordRepository restrictedWordRepository;

    public CosmicServiceImpl(Cosmic cosmic) {
        this.cosmic = cosmic;
        menfessRepository = MenfessRepositoryImpl.getInstance();
        userRepository = UserRepositoryImpl.getInstance();
        restrictedWordRepository = RestrictedWordRepositoryImpl.getInstance();
    }

    private void validateContent(String content)
            throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
            MenfessContentContainsRestrictedWordException {

        if (content.trim().isEmpty()) {
            throw new MenfessContentIsEmptyException();
        }

        if (content.length() > 280) {
            throw new MenfessContentIsTooLongException();
        }

        content = content.toLowerCase();
        for (String restrictedWord : restrictedWordRepository.getAllRestrictedWords()) {
            if (content.contains(restrictedWord)) {
                throw new MenfessContentContainsRestrictedWordException(restrictedWord);
            }
        }
    }

    @Override
    public void sendPromosiFess(String content)
            throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
            MenfessContentContainsRestrictedWordException {
        validateContent(content);

        Menfess menfess = new PromosiFess(cosmic, content);
        menfessRepository.addMenfess(menfess);
    }

    @Override
    public void sendCurhatFess(String content)
            throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
            MenfessContentContainsRestrictedWordException {
        validateContent(content);

        Menfess menfess = new CurhatFess(cosmic, content);
        menfessRepository.addMenfess(menfess);
    }

    @Override
    public void sendConfessFess(String content, String receiverUsername)
            throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
            UserByUsernameNotFoundException, MenfessContentContainsRestrictedWordException {
        validateContent(content);

        User receiver = userRepository.getUserByUsername(receiverUsername);
        if (receiver == null) {
            throw new UserByUsernameNotFoundException(receiverUsername);
        }

        Menfess menfess = new ConfessFess(cosmic, content, receiver);
        menfessRepository.addMenfess(menfess);
    }

    @Override
    public List<Menfess> getAllUnhiddenMenfesses() {
        return menfessRepository.getAllUnhiddenMenfesses();
    }

    @Override
    public List<Menfess> getAllSentMenfesses() {
        return menfessRepository.getAllMenfessesByUser(cosmic);
    }

    @Override
    public List<Menfess> getAllReceivedMenfesses() {
        return menfessRepository.getAllMenfessesForUser(cosmic);
    }

    @Override
    public void changePassword(String newPassword) throws PasswordDoesNotChangeException {
        for (User user : userRepository.getAllUsers()) {
            if (user.getId() == cosmic.getId() && user.getPassword().equals(newPassword)) {
                throw new PasswordDoesNotChangeException();
            }
        }
        userRepository.changePassword(cosmic, newPassword);
    }

    @Override
    public void logout() {
        BurhanFess.setCurrentDisplay(new UnauthorizedDisplay());
    }

}
