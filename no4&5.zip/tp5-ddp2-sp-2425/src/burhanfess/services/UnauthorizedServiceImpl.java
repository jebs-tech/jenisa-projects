package burhanfess.services;

import burhanfess.BurhanFess;
import burhanfess.displays.AdminDisplay;
import burhanfess.displays.CosmicDisplay;
import burhanfess.exceptions.InvalidUsernameOrPasswordException;
import burhanfess.exceptions.PasswordLengthTooShortException;
import burhanfess.exceptions.PasswordShouldContainLowerCaseLetterException;
import burhanfess.exceptions.PasswordShouldContainNumberException;
import burhanfess.exceptions.PasswordShouldContainUpperCaseLetterException;
import burhanfess.exceptions.UserByUsernameAlreadyExistsException;
import burhanfess.exceptions.UsernameContainsWhitespaceException;
import burhanfess.repositories.UserRepository;
import burhanfess.repositories.UserRepositoryImpl;
import burhanfess.users.Admin;
import burhanfess.users.Cosmic;
import burhanfess.users.User;

public class UnauthorizedServiceImpl implements UnauthorizedService {

    private UserRepository userRepository;

    public UnauthorizedServiceImpl() {
        this.userRepository = UserRepositoryImpl.getInstance();
    }
    
    @Override
    public void register(String username, String password) throws UserByUsernameAlreadyExistsException, UsernameContainsWhitespaceException, 
            PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException {

        // if (username.contains(" ")) {
        //     throw new UsernameContainsWhitespaceException();
        // }

        // if (password.length() < 8) {
        //     throw new PasswordLengthTooShortException();
        // }

        // if (!password.matches(".*[A-Z].*")) {
        //     throw new PasswordShouldContainUpperCaseLetterException();
        // }

        // if (!password.matches(".*[a-z].*")) {
        //     throw new PasswordShouldContainLowerCaseLetterException();
        // }

        // if (!password.matches(".*\\d.*")) {
        //     throw new PasswordShouldContainNumberException();
        // }
        
        for (User user : userRepository.getAllUsers()) {
            if (user.getUsername().equals(username)) {
                throw new UserByUsernameAlreadyExistsException(username);
            }
        }

        userRepository.addUser(new Cosmic(username, password));
    }

    @Override
    public void login(String username, String password) throws InvalidUsernameOrPasswordException {
        for (User user : userRepository.getAllUsers()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                if (user instanceof Admin admin) {
                    BurhanFess.setCurrentDisplay(new AdminDisplay(admin));
                } else {
                    BurhanFess.setCurrentDisplay(new CosmicDisplay((Cosmic) user));
                }
                return;
            }
        }

        throw new InvalidUsernameOrPasswordException();
    }

    @Override
    public void exit() {
        BurhanFess.setCurrentDisplay(null);
    }
    
}
