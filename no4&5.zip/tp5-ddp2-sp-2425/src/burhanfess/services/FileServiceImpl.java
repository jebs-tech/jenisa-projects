package burhanfess.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

import burhanfess.menfess.ConfessFess;
import burhanfess.menfess.CurhatFess;
import burhanfess.menfess.Menfess;
import burhanfess.menfess.PromosiFess;
import burhanfess.repositories.*;
import burhanfess.users.Admin;
import burhanfess.users.Cosmic;
import burhanfess.users.User;

public class FileServiceImpl implements FileService {

    private UserRepository userRepository;
    private MenfessRepository menfessRepository;
    private static final String SEPARATOR = "%";
    private static final String USERS_FILENAME = "users.txt";
    private static final String MENFESSES_FILENAME = "menfesses.txt";

    public FileServiceImpl() {
        this.userRepository = UserRepositoryImpl.getInstance();
        this.menfessRepository = MenfessRepositoryImpl.getInstance();
    }

    @Override
    public void saveUsers() throws FileNotFoundException {
        File userFile = new File(USERS_FILENAME);
        PrintWriter writer = new PrintWriter(userFile);

        for (User user : userRepository.getAllUsers()) {
            StringBuilder userData = new StringBuilder();
            userData.append(user.getId()).append(SEPARATOR)
                    .append(user.getUsername()).append(SEPARATOR)
                    .append(user.getPassword()).append(SEPARATOR)
                    .append(user.getRole());
            writer.println(userData.toString());
        }

        writer.close();
    }

    @Override
    public void loadUsers() throws IOException {
        List<User> users = new ArrayList<>();
        File userFile = new File(USERS_FILENAME);

        if (!userFile.createNewFile()) {
            Scanner scanner = new Scanner(userFile);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(SEPARATOR);
                int id = Integer.parseInt(parts[0]);
                String username = parts[1];
                String password = parts[2];
                String role = parts[3];

                if (role.equalsIgnoreCase("admin")) {
                    users.add(new Admin(id, username, password));
                } else {
                    users.add(new Cosmic(id, username, password));
                }

            }
            scanner.close();
        }

        if (users.isEmpty()) {
            users.add(new Admin("admin", "admin"));
        }

        userRepository.loadUsers(users);
    }

    @Override
    public void saveMenfesses() throws FileNotFoundException {
        File menfessFile = new File(MENFESSES_FILENAME);
        PrintWriter writer = new PrintWriter(menfessFile);

        for (Menfess menfess : menfessRepository.getAllMenfesses()) {
            StringBuilder menfessData = new StringBuilder();
            menfessData.append(menfess.getId()).append(SEPARATOR)
                    .append(menfess.getUser().getUsername()).append(SEPARATOR)
                    .append(menfess.getContent()).append(SEPARATOR)
                    .append(menfess.getTimestampString()).append(SEPARATOR)
                    .append(menfess.isHidden()).append(SEPARATOR)
                    .append(menfess.getType());
                    
            if (menfess instanceof ConfessFess confessFess) {
                menfessData.append(SEPARATOR).append(confessFess.getReceiver().getUsername());
            }

            writer.println(menfessData.toString());
        }

        writer.close();
    }

    @Override
    public void loadMenfesses() throws IOException {
        List<Menfess> menfesses = new ArrayList<>();
        File menfessFile = new File(MENFESSES_FILENAME);

        if (!menfessFile.createNewFile()) {
            Scanner scanner = new Scanner(menfessFile);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(SEPARATOR);

                int id = Integer.parseInt(parts[0]);
                String userUsername = parts[1];
                String content = parts[2];
                String timestampString = parts[3];
                boolean isHidden = Boolean.parseBoolean(parts[4]);
                String type = parts[5];
                User user = userRepository.getUserByUsername(userUsername);

                switch (type) {
                    case "[Confession]":
                        String receiverUsername = parts[6];
                        User receiver = userRepository.getUserByUsername(receiverUsername);
                        menfesses.add(new ConfessFess(id, user, content, timestampString, isHidden, receiver));
                        break;

                    case "[Promosi]":
                        menfesses.add(new PromosiFess(id, user, content, timestampString, isHidden));
                        break;

                    default:
                        menfesses.add(new CurhatFess(id, user, content, timestampString, isHidden));
                        break;

                }
            }
            scanner.close();
        }

        menfessRepository.loadMenfesses(menfesses);
    }

}
