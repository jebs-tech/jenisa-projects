package burhanfess.services;

import java.util.Comparator;
import java.util.List;

import burhanfess.BurhanFess;
import burhanfess.displays.UnauthorizedDisplay;
import burhanfess.exceptions.MenfessByIdNotFoundException;
import burhanfess.exceptions.MenfessIsAlreadyHiddenException;
import burhanfess.exceptions.MenfessIsAlreadyUnhiddenException;
import burhanfess.exceptions.PasswordDoesNotChangeException;
import burhanfess.exceptions.PasswordLengthTooShortException;
import burhanfess.exceptions.PasswordShouldContainLowerCaseLetterException;
import burhanfess.exceptions.PasswordShouldContainNumberException;
import burhanfess.exceptions.PasswordShouldContainUpperCaseLetterException;
import burhanfess.exceptions.UserByUsernameAlreadyExistsException;
import burhanfess.exceptions.UserByUsernameNotFoundException;
import burhanfess.exceptions.UsernameContainsWhitespaceException;
import burhanfess.exceptions.WordAlreadyExistsException;
import burhanfess.menfess.Menfess;
import burhanfess.repositories.*;
import burhanfess.users.Admin;
import burhanfess.users.User;

public class AdminServiceImpl implements AdminService {

    private UserRepository userRepository;
    private MenfessRepository menfessRepository;
    private RestrictedWordRepository restrictedWordRepository;

    public AdminServiceImpl() {
        this.userRepository = UserRepositoryImpl.getInstance();
        this.menfessRepository = MenfessRepositoryImpl.getInstance();
        this.restrictedWordRepository = RestrictedWordRepositoryImpl.getInstance();
    }

    @Override
    public List<User> getAllUsers(Comparator<User> comparator) {
        List<User> users = userRepository.getAllUsers();
        users.sort(comparator);
        return users;
    }

    @Override
    public void addAdmin(String username, String password)
            throws UserByUsernameAlreadyExistsException, UsernameContainsWhitespaceException,
            PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException {

        // if (username.contains(" ")) {
        //     throw new UsernameContainsWhitespaceException();
        // }

        // if (password.length() < 8) {
        //     throw new PasswordLengthTooShortException();
        // }

        // if (!password.matches(".*[A-Z].*")) {
        //     throw new PasswordShouldContainUpperCaseLetterException();
        // }

        // if (!password.matches(".*[a-z].*")) {
        //     throw new PasswordShouldContainLowerCaseLetterException();
        // }

        // if (!password.matches(".*\\d.*")) {
        //     throw new PasswordShouldContainNumberException();
        // }

        for (User user : userRepository.getAllUsers()) {
            if (user.getUsername().equals(username)) {
                throw new UserByUsernameAlreadyExistsException(username);
            }
        }

        userRepository.addUser(new Admin(username, password));
    }

    @Override
    public void resetPassword(String username, String newPassword)
            throws PasswordDoesNotChangeException, UserByUsernameNotFoundException {
        User user = userRepository.getUserByUsername(username);

        if (user == null) {
            throw new UserByUsernameNotFoundException(username);
        }

        if (user.getPassword().equals(newPassword)) {
            throw new PasswordDoesNotChangeException();
        }

        userRepository.changePassword(user, newPassword);
    }

    @Override
    public List<Menfess> getAllHiddenMenfesses() {
        return menfessRepository.getAllHiddenMenfesses();
    }

    @Override
    public List<Menfess> getAllUnhiddenMenfesses() {
        return menfessRepository.getAllUnhiddenMenfesses();
    }

    @Override
    public void hideMenfess(int menfessId) throws MenfessByIdNotFoundException, MenfessIsAlreadyHiddenException {
        for (Menfess menfess : menfessRepository.getAllUnhiddenMenfesses()) {
            if (menfess.getId() == menfessId) {
                if (menfess.isHidden()) {
                    throw new MenfessIsAlreadyHiddenException(menfessId);
                } else {
                    menfessRepository.hideMenfess(menfess);
                    return;
                }
            }
        }

        throw new MenfessByIdNotFoundException(menfessId);
    }

    @Override
    public void unhideMenfess(int menfessId) throws MenfessByIdNotFoundException, MenfessIsAlreadyUnhiddenException {
        for (Menfess menfess : menfessRepository.getAllHiddenMenfesses()) {
            if (menfess.getId() == menfessId) {
                if (!menfess.isHidden()) {
                    throw new MenfessIsAlreadyUnhiddenException(menfessId);
                } else {
                    menfessRepository.unhideMenfess(menfess);
                    return;
                }
            }
        }

        throw new MenfessByIdNotFoundException(menfessId);
    }

    @Override
    public List<String> getAllRestrictedWords() {
        return restrictedWordRepository.getAllRestrictedWords();
    }

    @Override
    public void addRestrictedWord(String word) throws WordAlreadyExistsException {
        word = word.trim().toLowerCase();
        if (restrictedWordRepository.isRestrictedWordExisted(word)) {
            throw new WordAlreadyExistsException(word);
        }
        restrictedWordRepository.addRestrictedWord(word);
    }

    @Override
    public void logout() {
        BurhanFess.setCurrentDisplay(new UnauthorizedDisplay());
    }
}
