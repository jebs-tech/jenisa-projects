package burhanfess.services;

import java.util.List;

import burhanfess.exceptions.MenfessContentContainsRestrictedWordException;
import burhanfess.exceptions.MenfessContentIsEmptyException;
import burhanfess.exceptions.MenfessContentIsTooLongException;
import burhanfess.exceptions.PasswordDoesNotChangeException;
import burhanfess.exceptions.UserByUsernameNotFoundException;
import burhanfess.menfess.Menfess;

public interface CosmicService {

        public void sendPromosiFess(String content)
                        throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
                        MenfessContentContainsRestrictedWordException;

        public void sendCurhatFess(String content)
                        throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
                        MenfessContentContainsRestrictedWordException;

        public void sendConfessFess(String content, String receiverUsername)
                        throws MenfessContentIsEmptyException, MenfessContentIsTooLongException,
                        UserByUsernameNotFoundException, MenfessContentContainsRestrictedWordException;

        public List<Menfess> getAllUnhiddenMenfesses();

        public List<Menfess> getAllSentMenfesses();

        public List<Menfess> getAllReceivedMenfesses();

        public void changePassword(String newPassword) throws PasswordDoesNotChangeException;

        public void logout();
}
