package burhanfess.services;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileService {
    
    public void saveUsers() throws FileNotFoundException;
    
    public void loadUsers() throws IOException;

    public void saveMenfesses() throws FileNotFoundException;

    public void loadMenfesses() throws IOException;
}
