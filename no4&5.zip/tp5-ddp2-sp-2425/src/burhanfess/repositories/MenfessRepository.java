package burhanfess.repositories;

import burhanfess.users.User;
import burhanfess.menfess.Menfess;
import java.util.List;

public interface MenfessRepository {

    public void loadMenfesses(List<Menfess> menfesses);

    public List<Menfess> getAllMenfesses();

    public List<Menfess> getAllMenfessesByUser(User user);

    public List<Menfess> getAllHiddenMenfesses();

    public List<Menfess> getAllUnhiddenMenfesses();

    public void addMenfess(Menfess menfess);

    public void hideMenfess(Menfess menfess);

    public void unhideMenfess(Menfess menfess);

    public List<Menfess> getAllMenfessesForUser(User user);
}
