package burhanfess.repositories;

import java.util.List;

public interface RestrictedWordRepository {
    
    public List<String> getAllRestrictedWords();

    public void addRestrictedWord(String word);

    public boolean isRestrictedWordExisted(String word);

}
