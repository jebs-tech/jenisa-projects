package burhanfess.repositories;

import java.util.ArrayList;
import java.util.List;

import burhanfess.users.User;

public class UserRepositoryImpl implements UserRepository {
    
    private List<User> users;
    private static UserRepository userRepository;

    private UserRepositoryImpl() {
        users = new ArrayList<>();
    }

    public static UserRepository getInstance() {
        if (userRepository == null) {
            userRepository = new UserRepositoryImpl();
        }
        return userRepository;
    }

    @Override
    public void loadUsers(List<User> users) {
        this.users = users;
    }

    @Override
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    @Override
    public User getUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }

        return null;
    }

    @Override
    public void addUser(User user) {
        users.add(user);
    }

    @Override
    public void changePassword(User user, String newPassword) {
        for (User currentUser : users) {
            if (currentUser.getId() == user.getId()) {
                currentUser.setPassword(newPassword);
                return;
            }
        }
    }

    @Override
    public int jumlahUser() {
        return users.size();
    }

}
