package burhanfess;

import java.io.IOException;

import burhanfess.displays.Display;
import burhanfess.displays.UnauthorizedDisplay;
import burhanfess.logs.LogFilterImpl;
import burhanfess.logs.LogService;
import burhanfess.services.FileServiceImpl;
import burhanfess.services.FileService;
import burhanfess.simpleStatistic.SimpleStatistic;

public class BurhanFess{
    
    private static Display currentDisplay = new UnauthorizedDisplay();
    private FileService fileService;
    
    public BurhanFess() throws IOException {
        fileService = new FileServiceImpl();
        run();
        SimpleStatistic simple = new SimpleStatistic();
        simple.printSimpleStatistic();
        LogService l = new LogService();
        l.readFile("users.txt");
        l.filterLog(log -> log.contains("hafiz"));
        l.filterLog(log -> log.startsWith("0"));
        l.filterLog(log -> log.endsWith("ic"));
        l.filterLog(new LogFilterImpl());
    }

    private void run() throws IOException {
        fileService.loadUsers();
        fileService.loadMenfesses();

        while (currentDisplay != null) {
            currentDisplay.run();
        }

        fileService.saveUsers();
        fileService.saveMenfesses();
    }

    public static void setCurrentDisplay(Display display) {
        currentDisplay = display;
    }
}
