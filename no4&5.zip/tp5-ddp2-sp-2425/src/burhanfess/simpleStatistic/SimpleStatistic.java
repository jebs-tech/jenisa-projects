package burhanfess.simpleStatistic;

import burhanfess.repositories.*;
import burhanfess.users.Cosmic;

public class SimpleStatistic {
    private MenfessRepository menfessRepository;
    private UserRepository userRepository;

    public SimpleStatistic() {
        menfessRepository = MenfessRepositoryImpl.getInstance();
        userRepository = UserRepositoryImpl.getInstance();
    }

    public void printSimpleStatistic(){
        System.out.println("Terima kasih telah menggunakan Burhanfess. Sampai Jumpa!");
        System.out.println("Total Pengguna : "+userRepository.jumlahUser());
        System.out.println("Total Menfess : "+menfessRepository.getAllMenfesses().size());
        System.out.println("-----------------------------------------------------------------------------------");
    }
}