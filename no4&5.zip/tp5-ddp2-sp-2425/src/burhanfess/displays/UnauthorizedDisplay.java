package burhanfess.displays;

import burhanfess.exceptions.InvalidInputException;
import burhanfess.exceptions.UserByUsernameAlreadyExistsException;
import burhanfess.exceptions.UsernameContainsWhitespaceException;
import burhanfess.services.UnauthorizedService;
import burhanfess.services.UnauthorizedServiceImpl;
import burhanfess.exceptions.InvalidUsernameOrPasswordException;
import burhanfess.exceptions.PasswordLengthTooShortException;
import burhanfess.exceptions.PasswordShouldContainLowerCaseLetterException;
import burhanfess.exceptions.PasswordShouldContainNumberException;
import burhanfess.exceptions.PasswordShouldContainUpperCaseLetterException;

public class UnauthorizedDisplay implements Display {

    private UnauthorizedService unauthorizedService;

    public UnauthorizedDisplay() {
        unauthorizedService = new UnauthorizedServiceImpl();
    }

    @Override
    public void showMenu() {
        System.out.println("Silakan pilih salah satu opsi berikut.");
        System.out.println("1. Registrasi");
        System.out.println("2. Login");
        System.out.println("3. Keluar");
    }

    @Override
    public void showHeader() {
        System.out.println("Selamat datang di Burhanfess");
        showCurrentDate();
        System.out.println("------------------------------------------------------------------------");
    }

    @Override
    public void run() {
        showHeader();
        while (true) {
            showMenu();
            System.out.print("Masukkan pilihan: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                System.out.println();

                switch (choice) {
                    case 1:
                        register();
                        break;

                    case 2:
                        login();
                        return;

                    case 3:
                        exit();
                        return;

                    default:
                        throw new InvalidInputException();

                }

            } catch (NumberFormatException e) {
                System.out.println();
                System.out.println("Input tidak valid. Silakan masukkan angka yang sesuai.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            System.out.println();
        }
    }

    public void register() throws UserByUsernameAlreadyExistsException, UsernameContainsWhitespaceException,
            PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException {
        System.out.println("Silakan masukkan username dan password untuk registrasi:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        unauthorizedService.register(username, password);
        System.out.println("Registrasi berhasil! Silakan login.");
    }

    public void login() throws InvalidUsernameOrPasswordException {
        System.out.println("Silakan masukkan username dan password untuk login:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        unauthorizedService.login(username, password);
        System.out.println(String.format("Login berhasil! Selamat datang, %s!", username));
        showFooter();
        System.out.println();
    }

    public void exit() {
        System.out.println("Terima kasih telah menggunakan Burhanfess. Sampai jumpa!");
        showFooter();
        scanner.close();
        unauthorizedService.exit();
    }

}
