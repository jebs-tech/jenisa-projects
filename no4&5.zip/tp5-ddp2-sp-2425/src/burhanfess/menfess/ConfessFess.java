package burhanfess.menfess;

import burhanfess.users.User;

public class ConfessFess extends Menfess {
    
    private User receiver;

    public ConfessFess(User user, String content, User receiver) {
        super(user, content);
        this.receiver = receiver;
    }

    public ConfessFess(User user, String content, User receiver, int delay) {
        super(user, content, delay);
        this.receiver = receiver;
    }

    public ConfessFess(int id, User user, String content, String timestampString, boolean isHidden, User receiver) {
        super(id, user, content, timestampString, isHidden);
        this.receiver = receiver;
    }

    @Override
    public String getType() {
        return "[Confession]";
    }
    
    public User getReceiver() {
        return receiver;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s oleh anonim%n", getType()));
        sb.append(super.toString());
        return sb.toString();
    }
}
