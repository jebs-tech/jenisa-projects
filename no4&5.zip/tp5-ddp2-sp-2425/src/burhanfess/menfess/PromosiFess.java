package burhanfess.menfess;

import burhanfess.users.User;

public class PromosiFess extends Menfess {
    
    public PromosiFess(User user, String content) {
        super(user, content);
    }

    public PromosiFess(User user, String content, int delay) {
        super(user, content, delay);
    }

    public PromosiFess(int id, User user, String content, String timestampString, boolean isHidden) {
        super(id, user, content, timestampString, isHidden);
    }
    
    @Override
    public String getType() {
        return "[Promosi]";
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s oleh %s%n", getType(), user.getUsername()));
        sb.append(super.toString());
        return sb.toString();
    }
}
