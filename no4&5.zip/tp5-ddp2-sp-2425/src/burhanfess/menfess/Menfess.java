package burhanfess.menfess;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import burhanfess.users.User;

public abstract class Menfess {
    
    private static int idGenerator = 0;
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    private int id;
    protected LocalDateTime timestamp;
    protected String content;
    private boolean isHidden;
    protected User user;

    public Menfess(User user, String content) {
        id = idGenerator++;
        this.user = user;
        this.content = content;
        timestamp = LocalDateTime.now();
        isHidden = false;
    }

    public Menfess(int id, User user, String content, String timestampString, boolean isHidden) {
        this.id = id;
        this.user = user;
        this.content = content;
        timestamp = LocalDateTime.parse(timestampString, formatter);
        this.isHidden = isHidden;
        idGenerator = Math.max(idGenerator, id + 1);
    }

    public Menfess(User user, String content, int delay) {
        this(user, content);
        timestamp = timestamp.plusSeconds(delay);
    }

    public User getUser() {
        return user;
    }

    public boolean isHidden() {
        return isHidden;
    }

    public int getId() {
        return id;
    }

    public void hide() {
        isHidden = true;
    }

    public void unhide() {
        isHidden = false;
    }

    public String getContent() {
        return content;
    }

    public String getTimestampString() {
        return timestamp.format(formatter);
    }

    public abstract String getType();

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("ID: %d%n", id));
        sb.append(String.format("%s%n", content));
        sb.append(String.format("Dikirim pada %s%n", timestamp.format(formatter)));
        return sb.toString();
    }
}
