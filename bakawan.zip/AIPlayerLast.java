public class AIPlayerLast extends Player {

    /**
     * Constructs an AI player with an empty hand.
     */
    public AIPlayerLast(String name) {
        super(name);
    }

    public Card searchForMatch(Card prev) {
        for (int i = getHand().size()-1; i >= 0; i--) {
            Card card = getHand().getCard(i);
            if (cardMatches(card, prev)) {
                return getHand().popCard(i);
            }
        }
        return null;
    }


}