import java.util.ArrayList;
import java.util.Scanner;


/**
 * Simulates a game of Crazy Eights.
 * See https://en.wikipedia.org/wiki/Crazy_Eights.
 */
public class Eights {

    // private Player one;
    // private Player two;
    // private Player three;
    // private Player four;
    // private Player five;

    private static ArrayList<Player> players = new ArrayList<Player>();
    private static ArrayList<Integer> scores = new ArrayList<Integer>();

    private Hand drawPile;
    private Hand discardPile;
    private Scanner in;

    /**
     * Initializes the state of the game.
     */
    public Eights() {
        Deck deck = new Deck("Deck");
        deck.shuffle();


        for (Player player : players) {
            player.setHand(new Hand(player.getName()));
            deck.deal(player.getHand(), 5);
        }


        // turn one card face up
        discardPile = new Hand("Discards");
        deck.deal(discardPile, 1);

        // put the rest of the deck face down
        drawPile = new Hand("Draw pile");
        deck.dealAll(drawPile);

        // create the scanner 
        // we'll use to wait for the user to press enter
        in = new Scanner(System.in);
    }

    /**
     * Returns true if either hand is empty.
     */
    public boolean isDone() {
       
        
        // return one.getHand().isEmpty() || two.getHand().isEmpty() || three.getHand().isEmpty() || four.getHand().isEmpty() || five.getHand().isEmpty();
        for (Player player : players) {
            if (player.getHand().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Moves cards from the discard pile to the draw pile and shuffles.
     */
    public void reshuffle() {
        // save the top card
        Card prev = discardPile.popCard();

        // move the rest of the cards
        discardPile.dealAll(drawPile);

        // put the top card back
        discardPile.addCard(prev);

        // shuffle the draw pile
        drawPile.shuffle();
    }

    /**
     * Returns a card from the draw pile.
     */
    public Card drawCard() {
        if (drawPile.isEmpty()) {
            reshuffle();
        }
        return drawPile.popCard();
    }

    /**
     * Switches players.
     */
    public Player nextPlayer(Player current) {


        int currentIndex = players.indexOf(current);

        int nextIndex = (currentIndex + 1) % players.size();
        return players.get(nextIndex);
    }

    /**
     * Displays the state of the game.
     */
    public void displayState() {
        for(int i=0;i<players.size();i++) {
            players.get(i).display();
        }   
        discardPile.display();
        System.out.println("Draw pile: " + drawPile.size() + " cards");
        in.nextLine();
    }

    /**
     * One player takes a turn.
     */
    public void takeTurn(Player player) {
        Card prev = discardPile.lastCard();
        Card next = player.play(this, prev);
        discardPile.addCard(next);

        System.out.println(player.getName() + " plays " + next);
        System.out.println();
    }

    /**
     * Plays the game.
     */
    public void playGame() {
        Player player = players.get(0);
        // Player player = one;

        // keep playing until there's a winner
        while (!isDone()) {
            System.out.println("================================");
            displayState();
            takeTurn(player);
            player = nextPlayer(player);
        }
        for(int i=0;i<players.size();i++) {
            players.get(i).displayScore();
        }


        System.out.println("Game over!");
    }

    /**
     * Creates the game and runs it.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Masukkan banyak player");
        int jumlahPlayer = scanner.nextInt();
        scanner.nextLine();

        for(int i=1;i<=jumlahPlayer;i++) {
            scores.add(0);

            System.out.println(i+". Masukkan jenis: Human or AI?");
            String jenisPlayer = scanner.nextLine();

            Player newPlayer = null;

            if(jenisPlayer.equalsIgnoreCase("human")) {

                System.out.println("Masukkan nama player " + (i));
                String nama = scanner.nextLine();
                newPlayer = new HumanPlayer(nama);

            } else if(jenisPlayer.equalsIgnoreCase("ai")) {

                System.out.println("Last or Advanced?");
                String jenisAI = scanner.nextLine();

                if(jenisAI.equalsIgnoreCase("advanced")) {
                    newPlayer = new AIPlayerAdvanced("BOT "+(i)+" ADVANCED");
                } 
                else if(jenisAI.equalsIgnoreCase("last")) {
                    newPlayer = new AIPlayerLast("BOT "+(i)+" LAST");
                } 
            } 

            players.add(newPlayer);


        }
        
        System.out.println("Main berapa kali?");
        int jumlahMain = scanner.nextInt();


        for(int i=1;i<=jumlahMain;i++) {
            System.out.println("Main ke-" + i);
            Eights game = new Eights();
            game.playGame();

            for(int j=0;j<players.size();j++) {
                scores.set(j, scores.get(j) + game.players.get(j).score());
            }


            System.out.println("~~~~~~~~~~~GAME "+ i + " SELESAI~~~~~~~~~~~\n\n\n");
        }

        System.out.println("Skor Akhir:");
        for(int i=0;i<players.size();i++) {
            System.out.println(players.get(i).getName() + ": " + scores.get(i));
        }

    }

}