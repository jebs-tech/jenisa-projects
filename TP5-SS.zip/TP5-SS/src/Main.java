import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import burhanfess.BurhanFess;

public class Main {
    public static void main(String[] args) throws IOException{
        new BurhanFess();

    }
}
