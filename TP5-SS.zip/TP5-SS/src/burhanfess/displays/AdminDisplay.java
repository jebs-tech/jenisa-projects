package burhanfess.displays;

import burhanfess.users.Admin;
import burhanfess.users.User;
import burhanfess.users.comparators.*;
import burhanfess.exceptions.InvalidInputException;
import burhanfess.exceptions.MenfessByIdNotFoundException;
import burhanfess.exceptions.MenfessIsAlreadyHiddenException;
import burhanfess.exceptions.MenfessIsAlreadyUnhiddenException;
import burhanfess.exceptions.PasswordDoesNotChangeException;
import burhanfess.exceptions.PasswordLengthTooShortException;
import burhanfess.exceptions.PasswordShouldContainLowerCaseLetterException;
import burhanfess.exceptions.PasswordShouldContainNumberException;
import burhanfess.exceptions.PasswordShouldContainUpperCaseLetterException;
import burhanfess.exceptions.UserByUsernameAlreadyExistsException;
import burhanfess.exceptions.UserByUsernameNotFoundException;
import burhanfess.exceptions.UsernameContainsWhitespaceException;
import burhanfess.exceptions.WordAlreadyExistsException;
import burhanfess.menfess.Menfess;
import burhanfess.services.AdminService;
import burhanfess.services.AdminServiceImpl;

public class AdminDisplay implements Display {

    private Admin admin;
    private AdminService adminService;

    public AdminDisplay(Admin admin) {
        this.admin = admin;
        adminService = new AdminServiceImpl();
    }

    @Override
    public void showMenu() {
        System.out.println("Silakan pilih salah satu opsi berikut");
        System.out.println("1. Lihat daftar pengguna");
        System.out.println("2. Tambah admin");
        System.out.println("3. Reset password pengguna");
        System.out.println("4. Sembunyikan menfess");
        System.out.println("5. Tampilkan menfess");
        System.out.println("6. Tambahkan kata yang dibatasi");
        System.out.println("7. Logout");
    }

    @Override
    public void showHeader() {
        System.out.println("Halo, Admin " + admin.getUsername() + "!");
        showCurrentDate();
        System.out.println("------------------------------------------------------------------------");
    }

    @Override
    public void run() {
        showHeader();
        while (true) {
            showMenu();
            System.out.print("Masukkan pilihan: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                System.out.println();

                switch (choice) {
                    case 1:
                        showAllUsers();
                        break;

                    case 2:
                        addAdmin();
                        break;

                    case 3:
                        resetPassword();
                        break;

                    case 4:
                        hideMenfess();
                        break;

                    case 5:
                        unhideMenfess();
                        break;

                    case 6:
                        addRestrictedWord();
                        break;

                    case 7:
                        logout();
                        return;

                    default:
                        throw new InvalidInputException();

                }

            } catch (NumberFormatException e) {
                System.out.println("Input tidak valid. Silakan masukkan angka yang sesuai.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            System.out.println();
        }
    }

    private void showAllUsers() throws InvalidInputException, NumberFormatException {
        System.out.println("Silakan pilih opsi pengurutan:");
        System.out.println("1. Berdasarkan ID");
        System.out.println("2. Berdasarkan username");
        System.out.print("Masukkan pilihan: ");
        System.out.println();

        int choice = Integer.parseInt(scanner.nextLine());

        switch (choice) {
            case 1:
                System.out.println("Daftar pengguna diurutkan berdasarkan ID:");
                for (User user : adminService.getAllUsers(new UserIdComparator())) {
                    System.out.println(user);
                }
                break;

            case 2:
                System.out.println("Daftar pengguna diurutkan berdasarkan username:");
                for (User user : adminService.getAllUsers(new UserUsernameComparator())) {
                    System.out.println(user);
                }
                break;

            default:
                throw new InvalidInputException();
        }

    }

    private void addAdmin() throws UserByUsernameAlreadyExistsException, UsernameContainsWhitespaceException,
            PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException {
        System.out.println("Silakan masukkan username dan password untuk admin baru:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        adminService.addAdmin(username, password);
        System.out.println(String.format("Admin %s berhasil ditambahkan", username));
    }

    private void resetPassword() throws PasswordDoesNotChangeException, UserByUsernameNotFoundException,
            PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException {
        System.out.print("Masukkan username pengguna yang passwordnya ingin direset: ");
        String username = scanner.nextLine();
        System.out.print("Masukkan password baru: ");
        String newPassword = scanner.nextLine();

        adminService.resetPassword(username, newPassword);
        System.out.println("Password berhasil direset.");
    }

    private void hideMenfess()
            throws NumberFormatException, MenfessByIdNotFoundException, MenfessIsAlreadyHiddenException {
        System.out.println("Daftar menfess yang ditampilkan:");
        for (Menfess menfess : adminService.getAllUnhiddenMenfesses()) {
            System.out.println(menfess);
        }

        System.out.print("Masukkan ID menfess yang ingin disembunyikan: ");

        int menfessId = Integer.parseInt(scanner.nextLine());
        adminService.hideMenfess(menfessId);
        System.out.println("Menfess berhasil disembunyikan.");
    }

    private void unhideMenfess()
            throws NumberFormatException, MenfessByIdNotFoundException, MenfessIsAlreadyUnhiddenException {
        System.out.println("Daftar menfess yang disembunyikan:");
        for (Menfess menfess : adminService.getAllHiddenMenfesses()) {
            System.out.println(menfess);
        }

        System.out.print("Masukkan ID menfess yang ingin ditampilkan: ");
        int menfessId = Integer.parseInt(scanner.nextLine());
        adminService.unhideMenfess(menfessId);
        System.out.println("Menfess berhasil ditampilkan.");

    }

    private void addRestrictedWord() throws WordAlreadyExistsException {
        System.out.println("Daftar kata yang dibatasi:");
        for (int i = 0; i < adminService.getAllRestrictedWords().size(); i++) {
            System.out.println(String.format("%d. %s", i + 1, adminService.getAllRestrictedWords().get(i)));
        }
        System.out.println();

        System.out.print("Masukkan kata yang ingin dibatasi: ");
        String word = scanner.nextLine();

        adminService.addRestrictedWord(word);
        System.out.println(String.format("Kata %s berhasil ditambahkan ke daftar kata yang dibatasi", word));
    }

    private void logout() {
        System.out.println("Kamu telah berhasil logout.");
        showFooter();
        System.out.println();
        adminService.logout();
    }
}
