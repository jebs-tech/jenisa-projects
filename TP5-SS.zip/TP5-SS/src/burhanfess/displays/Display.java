package burhanfess.displays;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Scanner;

public interface Display {

    public DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, dd MMM yyyy",
            Locale.forLanguageTag("id-ID"));

    public Scanner scanner = new Scanner(System.in);

    public void showMenu();

    public void showHeader();

    public void run();

    public default void showFooter() {
        System.out.println("------------------------------------------------------------------------");
        System.out.println("BurhanFess - 2025");
        System.out.println("Created by Burhan");
    }

    public default void showCurrentDate() {
        System.out.println(LocalDate.now().format(formatter));
    }

}