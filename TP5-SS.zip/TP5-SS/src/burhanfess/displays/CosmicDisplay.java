package burhanfess.displays;

import burhanfess.exceptions.InvalidInputException;
import burhanfess.exceptions.MenfessContentContainsRestrictedWordException;
import burhanfess.exceptions.MenfessContentIsEmptyException;
import burhanfess.exceptions.MenfessContentIsTooLongException;
import burhanfess.exceptions.PasswordDoesNotChangeException;
import burhanfess.exceptions.UserByUsernameNotFoundException;
import burhanfess.menfess.*;
import burhanfess.services.CosmicService;
import burhanfess.services.CosmicServiceImpl;
import burhanfess.users.Cosmic;

public class CosmicDisplay implements Display {

    private Cosmic cosmic;
    private CosmicService cosmicService;

    public CosmicDisplay(Cosmic cosmic) {
        this.cosmic = cosmic;
        cosmicService = new CosmicServiceImpl(cosmic);
    }

    @Override
    public void showMenu() {
        System.out.println("Silakan pilih salah satu opsi berikut");
        System.out.println("1. Mengirim satu menfess");
        // System.out.println("2. Mengirim beberapa menfess sekaligus");
        System.out.println("2. Melihat menfess publik");
        System.out.println("3. Melihat menfess yang kamu kirim");
        System.out.println("4. Melihat menfess yang kamu terima");
        System.out.println("5. Ubah password");
        System.out.println("6. Logout");
    }

    @Override
    public void showHeader() {
        System.out.println("Halo, Cosmic " + cosmic.getUsername() + "!");
        showCurrentDate();
        System.out.println("------------------------------------------------------------------------");
    }

    @Override
    public void run() {
        showHeader();
        while (true) {
            showMenu();
            System.out.print("Masukkan pilihan: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());
                System.out.println();

                switch (choice) {
                    case 1:
                        sendMenfess();
                        break;

                    // case 2:
                    // sendMultipleMenfesses();
                    // break;

                    case 2:
                        viewUnhiddenMenfesses();
                        break;

                    case 3:
                        viewSentMenfesses();
                        break;

                    case 4:
                        viewReceivedMenfesses();
                        break;

                    case 5:
                        changePassword();
                        break;

                    case 6:
                        logout();
                        return;

                    default:
                        throw new InvalidInputException();
                }
            } catch (NumberFormatException e) {
                System.out.println();
                System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            System.out.println();
        }

    }

    private void sendMenfess() throws InvalidInputException,
            MenfessContentIsEmptyException, MenfessContentIsTooLongException,
            UserByUsernameNotFoundException, NumberFormatException,
            MenfessContentContainsRestrictedWordException {
        System.out.println("Masukkan isi menfess yang ingin kamu kirim:");
        String content = scanner.nextLine();

        System.out.println("Silakan pilih tipe menfess yang ingin dikirim.");
        System.out.println("1. Curhat");
        System.out.println("2. Promosi");
        System.out.println("3. Confession");
        System.out.print("Masukkan tipe menfess: ");
        int choice = Integer.parseInt(scanner.nextLine());
        System.out.println();

        switch (choice) {

            case 1:
                cosmicService.sendCurhatFess(content);
                break;

            case 2:
                cosmicService.sendPromosiFess(content);
                break;

            case 3:
                System.out.print("Masukkan username yang ingin kamu kirimkan menfess: ");
                String receiverUsername = scanner.nextLine();
                cosmicService.sendConfessFess(content, receiverUsername);
                break;

            default:
                throw new InvalidInputException();
        }

        System.out.println("Menfess berhasil dikirim.");
    }

    private void viewUnhiddenMenfesses() {
        System.out.println("Daftar menfess bersifat publik:");
        for (Menfess menfess : cosmicService.getAllUnhiddenMenfesses()) {
            System.out.println(menfess);
        }
    }

    private void viewSentMenfesses() {
        System.out.println("Daftar menfess yang kamu kirim:");
        for (Menfess menfess : cosmicService.getAllSentMenfesses()) {
            System.out.println(menfess);
        }
    }

    private void viewReceivedMenfesses() {
        System.out.println("Daftar menfess yang kamu terima:");
        for (Menfess menfess : cosmicService.getAllReceivedMenfesses()) {
            System.out.println(menfess);
        }
    }

    private void changePassword() throws PasswordDoesNotChangeException {
        System.out.print("Masukkan password baru: ");
        String newPassword = scanner.nextLine();

        cosmicService.changePassword(newPassword);
        System.out.println("Password berhasil diubah.");
    }

    private void logout() {
        System.out.println("Kamu telah berhasil logout.");
        showFooter();
        System.out.println();
        cosmicService.logout();
    }
}
