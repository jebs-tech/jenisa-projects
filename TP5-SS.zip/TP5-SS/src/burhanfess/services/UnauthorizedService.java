package burhanfess.services;

import burhanfess.exceptions.InvalidUsernameOrPasswordException;
import burhanfess.exceptions.PasswordLengthTooShortException;
import burhanfess.exceptions.PasswordShouldContainLowerCaseLetterException;
import burhanfess.exceptions.PasswordShouldContainNumberException;
import burhanfess.exceptions.PasswordShouldContainUpperCaseLetterException;
import burhanfess.exceptions.UserByUsernameAlreadyExistsException;
import burhanfess.exceptions.UsernameContainsWhitespaceException;

public interface UnauthorizedService {
    
    public void register(String username, String password) throws UserByUsernameAlreadyExistsException, UsernameContainsWhitespaceException,
            PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException;

    public void login(String username, String password) throws InvalidUsernameOrPasswordException;

    public void exit();
}
