package burhanfess.services;

import java.util.Comparator;
import java.util.List;

import burhanfess.exceptions.MenfessByIdNotFoundException;
import burhanfess.exceptions.MenfessIsAlreadyHiddenException;
import burhanfess.exceptions.MenfessIsAlreadyUnhiddenException;
import burhanfess.exceptions.UserByUsernameAlreadyExistsException;
import burhanfess.exceptions.UserByUsernameNotFoundException;
import burhanfess.exceptions.UsernameContainsWhitespaceException;
import burhanfess.exceptions.WordAlreadyExistsException;
import burhanfess.exceptions.PasswordDoesNotChangeException;
import burhanfess.exceptions.PasswordLengthTooShortException;
import burhanfess.exceptions.PasswordShouldContainLowerCaseLetterException;
import burhanfess.exceptions.PasswordShouldContainNumberException;
import burhanfess.exceptions.PasswordShouldContainUpperCaseLetterException;
import burhanfess.users.User;
import burhanfess.menfess.Menfess;

public interface AdminService {

    public List<User> getAllUsers(Comparator<User> comparator);

    public void addAdmin(String username, String password) throws UserByUsernameAlreadyExistsException,
            UsernameContainsWhitespaceException, PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException;

    public void resetPassword(String username, String newPassword) throws PasswordDoesNotChangeException,
            UserByUsernameNotFoundException, PasswordLengthTooShortException, PasswordShouldContainNumberException,
            PasswordShouldContainLowerCaseLetterException, PasswordShouldContainUpperCaseLetterException;

    public List<Menfess> getAllHiddenMenfesses();

    public List<Menfess> getAllUnhiddenMenfesses();

    public void hideMenfess(int menfessId) throws MenfessByIdNotFoundException, MenfessIsAlreadyHiddenException;

    public void unhideMenfess(int menfessId) throws MenfessByIdNotFoundException, MenfessIsAlreadyUnhiddenException;

    public List<String> getAllRestrictedWords();

    public void addRestrictedWord(String word) throws WordAlreadyExistsException;

    public void logout();

}
