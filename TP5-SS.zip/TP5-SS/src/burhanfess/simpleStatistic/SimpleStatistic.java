package burhanfess.simpleStatistic;

import burhanfess.repositories.*;

public class SimpleStatistic {
    private MenfessRepository menfessRepository;
    private UserRepository userRepository;

    public SimpleStatistic(){
        menfessRepository = MenfessRepositoryImpl.getInstance();
        userRepository = UserRepositoryImpl.getInstance();
    }

    public void printStatistics() {
        System.out.println("Total Menfess: " + menfessRepository.getAllMenfesses().size());
        System.out.println("Total Pengguna: " + userRepository.getAllUsers().size());
    }
}