package burhanfess.repositories;

import burhanfess.users.*;

import java.util.List;

public interface UserRepository {

    public void loadUsers(List<User> users);

    public List<User> getAllUsers();

    public User getUserByUsername(String username);

    public void addUser(User user);

    public void changePassword(User user, String newPassword);
}
