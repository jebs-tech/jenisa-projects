package burhanfess.repositories;

import java.util.List;
import java.util.ArrayList;

public class RestrictedWordRepositoryImpl implements RestrictedWordRepository {
    
    private static RestrictedWordRepository restrictedWordRepository;
    private List<String> restrictedWords;

    private RestrictedWordRepositoryImpl() {
        restrictedWords = new ArrayList<>();
    }

    public static RestrictedWordRepository getInstance() {
        if (restrictedWordRepository == null) {
            restrictedWordRepository = new RestrictedWordRepositoryImpl();
        }
        return restrictedWordRepository;
    }

    @Override
    public List<String> getAllRestrictedWords() {
        return new ArrayList<>(restrictedWords);
    }

    @Override
    public void addRestrictedWord(String word) {
        restrictedWords.add(word);
    }

    @Override
    public boolean isRestrictedWordExisted(String word) {
        return restrictedWords.contains(word);
    }
}
