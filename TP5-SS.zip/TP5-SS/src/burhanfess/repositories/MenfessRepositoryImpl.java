package burhanfess.repositories;

import java.util.List;
import java.util.ArrayList;

import burhanfess.menfess.ConfessFess;
import burhanfess.menfess.Menfess;
import burhanfess.users.User;

public class MenfessRepositoryImpl implements MenfessRepository {

    private List<Menfess> menfesses;
    private static MenfessRepository menfessRepository;

    private MenfessRepositoryImpl() {
        menfesses = new ArrayList<>();
    }

    public static MenfessRepository getInstance() {
        if (menfessRepository == null) {
            menfessRepository = new MenfessRepositoryImpl();
        }
        return menfessRepository;
    }

    @Override
    public void loadMenfesses(List<Menfess> menfesses) {
        this.menfesses = menfesses;
    }

    @Override
    public List<Menfess> getAllMenfesses() {
        return new ArrayList<>(menfesses);
    }

    @Override
    public List<Menfess> getAllMenfessesByUser(User user) {
        List<Menfess> menfessesByUser = new ArrayList<>();
        for (Menfess menfess : menfesses) {
            if (menfess.getUser().equals(user)) {
                menfessesByUser.add(menfess);
            }
        }

        return menfessesByUser;
    }

    @Override
    public List<Menfess> getAllHiddenMenfesses() {
        List<Menfess> hiddenMenfesses = new ArrayList<>();
        for (Menfess menfess : menfesses) {
            if (menfess.isHidden()) {
                hiddenMenfesses.add(menfess);
            }
        }

        return hiddenMenfesses;
    }

    @Override
    public List<Menfess> getAllUnhiddenMenfesses() {
        List<Menfess> unhiddenMenfesses = new ArrayList<>();
        for (Menfess menfess : menfesses) {
            if (!menfess.isHidden()) {
                unhiddenMenfesses.add(menfess);
            }
        }

        return unhiddenMenfesses;
    }

    @Override
    public void addMenfess(Menfess menfess) {
        menfesses.add(menfess);
    }

    @Override
    public void hideMenfess(Menfess menfess) {
        menfess.hide();
    }

    @Override
    public void unhideMenfess(Menfess menfess) {
        menfess.unhide();
    }

    @Override
    public List<Menfess> getAllMenfessesForUser(User user) {
        List<Menfess> userMenfesses = new ArrayList<>();

        for (Menfess menfess : menfesses) {
            if (menfess instanceof ConfessFess confessFess && confessFess.getReceiver().equals(user) && !confessFess.isHidden()) {
                userMenfesses.add(confessFess);
            }
        }

        return userMenfesses;
    }
    
}
