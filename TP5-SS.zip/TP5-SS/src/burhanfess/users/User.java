package burhanfess.users;

public abstract class User {

    private static int idGenerator = 0;
    private int id;
    private String username;
    private String password;

    public User(String username, String password) {
        id = idGenerator++;
        this.username = username;
        this.password = password;
    }

    public User(int id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
        idGenerator = Math.max(idGenerator, id + 1);
    }

    public int getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public abstract String getRole();

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("ID: %d%n", id));
        sb.append(String.format("Username: %s%n", username));
        sb.append(String.format("Role: %s%n", getRole()));
        return sb.toString();
    }

}
