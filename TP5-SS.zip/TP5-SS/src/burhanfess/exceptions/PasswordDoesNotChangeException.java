package burhanfess.exceptions;

public class PasswordDoesNotChangeException extends Exception {
    
    public PasswordDoesNotChangeException() {
        super("Password yang dimasukkan tidak boleh sama dengan password sebelumnya");
    }

}
