package burhanfess.exceptions;

public class MenfessIsAlreadyHiddenException extends Exception {
    
    public MenfessIsAlreadyHiddenException(int menfessId) {
        super(String.format("Menfess dengan ID %d sudah disembunyikan", menfessId));
    }
}
