package burhanfess.exceptions;

public class UserByUsernameAlreadyExistsException extends Exception {

    public UserByUsernameAlreadyExistsException(String username) {
        super(String.format("User dengan username '%s' sudah ada", username));
    }
    
}
