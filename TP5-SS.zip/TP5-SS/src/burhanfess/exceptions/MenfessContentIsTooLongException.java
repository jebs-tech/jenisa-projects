package burhanfess.exceptions;

public class MenfessContentIsTooLongException extends Exception {
    
    public MenfessContentIsTooLongException() {
        super("Isi menfess terlalu panjang. Isi menfess maksimal 280 karakter");
    }
}
