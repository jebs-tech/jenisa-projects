package burhanfess.exceptions;

public class PasswordShouldContainLowerCaseLetterException extends Exception {

    public PasswordShouldContainLowerCaseLetterException() {
        super("Password harus mengandung setidaknya satu huruf kecil.");
    }
    
}
