package burhanfess.exceptions;

public class InvalidUsernameOrPasswordException extends Exception {

    public InvalidUsernameOrPasswordException() {
        super("Username atau password salah. Silakan coba lagi.");
    }
    
}
