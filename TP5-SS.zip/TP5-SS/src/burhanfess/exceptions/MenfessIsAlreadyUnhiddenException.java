package burhanfess.exceptions;

public class MenfessIsAlreadyUnhiddenException extends Exception {

    public MenfessIsAlreadyUnhiddenException(int menfessId) {
        super(String.format("Menfess dengan ID %d sudah ditampilkan", menfessId));
    }
}
