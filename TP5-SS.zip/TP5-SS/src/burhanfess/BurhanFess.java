package burhanfess;

import java.io.IOException;

import burhanfess.displays.Display;
import burhanfess.displays.UnauthorizedDisplay;
import burhanfess.services.FileServiceImpl;
import burhanfess.services.FileService;

public class BurhanFess{
    
    private static Display currentDisplay = new UnauthorizedDisplay();
    private FileService fileService;
    
    public BurhanFess() throws IOException {
        fileService = new FileServiceImpl();
        run();
        SimpleStatistic simpleStatistic = new SimpleStatistic();
        simpleStatistic.printStatistics();
    }

    private void run() throws IOException {
        fileService.loadUsers();
        fileService.loadMenfesses();

        while (currentDisplay != null) {
            currentDisplay.run();
        }

        fileService.saveUsers();
        fileService.saveMenfesses();
    }

    public static void setCurrentDisplay(Display display) {
        currentDisplay = display;
    }
}
