/**
 * Interface untuk ability card yang memberikan efek khusus dalam permainan
 */
public interface AbilityCard {
    /**
     * Mengaktifkan efek dari ability card
     * @param eights - game instance untuk akses ke game state
     * @param currentPlayer - pemain yang memainkan ability card
     */
    void activateEffect(Eights eights, Player currentPlayer);
    
    /**
     * Mendapatkan nama efek ability card
     * @return nama efek
     */
    String getEffectName();
    
    /**
     * Mengecek apakah kartu tertentu adalah ability card untuk ronde ini
     * @param card - kartu yang dicek
     * @param abilityCard - kartu yang menjadi ability card
     * @return true jika kartu adalah ability card
     */
    boolean isAbilityCard(Card card, Card abilityCard);
}