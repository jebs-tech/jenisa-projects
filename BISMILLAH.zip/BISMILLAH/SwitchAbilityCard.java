import java.util.ArrayList;

/**
 * Implementasi ability card yang menukar kartu semua pemain dengan pemain berikutnya
 */
public class SwitchAbilityCard implements AbilityCard {
    
    @Override
    public void activateEffect(Eights eights, Player currentPlayer) {
        System.out.println("Efek SwitchAbilityCard aktif: Semua pemain menukar kartu dengan pemain berikutnya.");
        
        ArrayList<Player> players = eights.getPlayers();
        ArrayList<Hand> originalHands = new ArrayList<>();
        
        // Simpan semua hand asli
        for (Player player : players) {
            originalHands.add(player.getHand());
        }
        
        // Tukar hand dengan pemain berikutnya
        for (int i = 0; i < players.size(); i++) {
            int nextPlayerIndex = (i + 1) % players.size();
            players.get(i).setHand(originalHands.get(nextPlayerIndex));
            players.get(i).getHand().setLabel(players.get(i).getName());
        }
        
        System.out.println("== Setelah Efek SwitchAbilityCard ==");
        for (Player player : players) {
            System.out.print(player.getName() + " sekarang memiliki: ");
            for (int i = 0; i < player.getHand().size(); i++) {
                System.out.print(player.getHand().getCard(i));
                if (i < player.getHand().size() - 1) {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }
    
    @Override
    public String getEffectName() {
        return "SwitchAbilityCard";
    }
    
    @Override
    public boolean isAbilityCard(Card card, Card abilityCard) {
        return card.equals(abilityCard);
    }
}