
public class AIPlayerAdvanced extends Player {

    /**
     * Constructs an AI player with an empty hand.
     */
    public AIPlayerAdvanced(String name) {
        super(name);
    }

    public Card searchForMatch(Card prev) {
        int bestCardIndex = -1;
        int bestRank = -1;

        // Iterate through the hand to find the best card to play
        for (int i = 0; i < getHand().size(); i++) {
            Card card = getHand().getCard(i);
            if (cardMatches(card, prev)) {
                // If the card matches, check if it's the best one
                if (card.getRank() > bestRank) {
                    bestRank = card.getRank();
                    bestCardIndex = i;
                }
            }
        }
        
        if(bestCardIndex == -1) {
            return null;
        } else {
            return getHand().popCard(bestCardIndex);
        }
    }
}
