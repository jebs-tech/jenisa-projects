

import java.util.Scanner;

public class HumanPlayer extends Player {

    /**
     * Constructs a human player with an empty hand.
     */
    public HumanPlayer(String name) {
        super(name);
    }
   
    @Override
    public Card searchForMatch(Card prev) {
        Scanner scanner = new Scanner(System.in);
        
        Card card=null;
        boolean KartuSama = false;
        for (int i = 0; i < this.getHand().size(); i++) {
            if ( prev.KartuMatch(getHand().getCard(i))){ // kalau sama 
                KartuSama = true;
            }
            
        }
        
        while (KartuSama) { 
            System.out.println("Masukkan kartu yang ingin dimainkan:");
            String input = scanner.nextLine();
            card = searchKartuByInput(input);
            if(card != null) {
                if (cardMatches(card, prev)) {
                    System.out.println("Kartu " + card + " cocok dengan kartu sebelumnya " + prev);
                    break;
                } else {
                    System.out.println("Kartu " + card + " tidak cocok dengan kartu sebelumnya " + prev);
                }
            }  else {
                System.out.println("Kartu tidak ditemukan di tangan Anda. Silakan coba lagi.");
            }
            
        }
        if (KartuSama == false){
        System.out.println("Kartu yang kamu miliki tidak ada yang sama, silahkan ambil kartu");
        }
        return card; 
    }

    public Card searchKartuByInput(String input) {
        for (int i = 0; i < this.getHand().size(); i++) {
            Card card = getHand().getCard(i);

            if (card.toString().equalsIgnoreCase(input)) {
                return getHand().popCard(i);
            }
        }
        return null;
    }
}
