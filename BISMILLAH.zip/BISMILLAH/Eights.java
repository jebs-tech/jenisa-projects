import java.util.ArrayList;
import java.util.Scanner;

/**
 * Simulates a game of Crazy Eights with Ability Card feature.
 * See https://en.wikipedia.org/wiki/Crazy_Eights.
 */
public class Eights {

    private static ArrayList<Player> players = new ArrayList<Player>();
    private static ArrayList<Integer> scores = new ArrayList<Integer>();

    private Hand drawPile;
    private Hand discardPile;
    private Scanner in;
    
    // Ability card feature
    private Card abilityCard;
    private AbilityCard abilityCardEffect;
    private int currentRound = 1;

    /**
     * Initializes the state of the game.
     */
    public Eights() {
        Deck deck = new Deck("Deck");
        deck.shuffle();

        for (Player player : players) {
            player.setHand(new Hand(player.getName()));
            deck.deal(player.getHand(), 5);
        }

        // turn one card face up
        discardPile = new Hand("Discards");
        deck.deal(discardPile, 1);

        // put the rest of the deck face down
        drawPile = new Hand("Draw pile");
        deck.dealAll(drawPile);

        // create the scanner 
        // we'll use to wait for the user to press enter
        in = new Scanner(System.in);
        
        // Initialize ability card effect
        abilityCardEffect = new SwitchAbilityCard();
    }

    /**
     * Returns true if either hand is empty.
     */
    public boolean isDone() {
        for (Player player : players) {
            if (player.getHand().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Moves cards from the discard pile to the draw pile and shuffles.
     */
    public void reshuffle() {
        // save the top card
        Card prev = discardPile.popCard();

        // move the rest of the cards
        discardPile.dealAll(drawPile);

        // put the top card back
        discardPile.addCard(prev);

        // shuffle the draw pile
        drawPile.shuffle();
    }

    /**
     * Returns a card from the draw pile.
     */
    public Card drawCard() {
        if (drawPile.isEmpty()) {
            reshuffle();
        }
        return drawPile.popCard();
    }

    /**
     * Switches players.
     */
    public Player nextPlayer(Player current) {
        int currentIndex = players.indexOf(current);
        int nextIndex = (currentIndex + 1) % players.size();
        return players.get(nextIndex);
    }

    /**
     * Displays the state of the game.
     */
    public void displayState() {
        System.out.println("Giliran " + getCurrentPlayerName());
        getCurrentPlayer().display();
        System.out.println("Draw pile: " + drawPile.size() + " cards");
        System.out.println("Last card: " + discardPile.lastCard());
        System.out.println();
    }
    
    private String getCurrentPlayerName() {
        // This method would need the current player context
        return "Current Player";
    }
    
    private Player getCurrentPlayer() {
        // This method would need the current player context
        return players.get(0);
    }

    /**
     * One player takes a turn.
     */
    public void takeTurn(Player player) {
        Card prev = discardPile.lastCard();
        Card next = player.play(this, prev);
        discardPile.addCard(next);

        System.out.println(player.getName() + " memainkan " + next);
        
        // Check if the played card is an ability card
        if (abilityCard != null && abilityCardEffect.isAbilityCard(next, abilityCard)) {
            System.out.println(player.getName() + " memainkan " + next + " (Ability Card)!");
            abilityCardEffect.activateEffect(this, player);
        }
        
        System.out.println();
    }

    /**
     * Sets up the ability card for the round
     */
    public void setupAbilityCard() {
        System.out.println("RONDE " + currentRound);
        
        Player firstPlayer = players.get(0);
        System.out.print(firstPlayer.getName() + ", ketikkan nama kartu yang akan menjadi Ability Card: ");
        
        Scanner scanner = new Scanner(System.in);
        String cardInput = scanner.nextLine();
        
        // Find the card in the first player's hand or create it for demonstration
        abilityCard = findCardByName(cardInput);
        if (abilityCard == null) {
            // For demonstration, create the card based on input
            abilityCard = parseCardFromString(cardInput);
        }
        
        System.out.println("Ability Card untuk ronde ini adalah: " + abilityCard);
        System.out.println();
    }
    
    /**
     * Parse card from string input
     */
    private Card parseCardFromString(String cardString) {
        // Simple parser for card strings like "Jack of Spades"
        String[] parts = cardString.split(" of ");
        if (parts.length != 2) {
            return new Card(11, 3); // Default to Jack of Spades
        }
        
        String rankStr = parts[0];
        String suitStr = parts[1];
        
        int rank = parseRank(rankStr);
        int suit = parseSuit(suitStr);
        
        return new Card(rank, suit);
    }
    
    private int parseRank(String rankStr) {
        switch (rankStr.toLowerCase()) {
            case "ace": return 1;
            case "jack": return 11;
            case "queen": return 12;
            case "king": return 13;
            default:
                try {
                    return Integer.parseInt(rankStr);
                } catch (NumberFormatException e) {
                    return 11; // Default to Jack
                }
        }
    }
    
    private int parseSuit(String suitStr) {
        switch (suitStr.toLowerCase()) {
            case "clubs": return 0;
            case "diamonds": return 1;
            case "hearts": return 2;
            case "spades": return 3;
            default: return 3; // Default to Spades
        }
    }
    
    /**
     * Find card by name in all players' hands
     */
    private Card findCardByName(String cardName) {
        for (Player player : players) {
            for (int i = 0; i < player.getHand().size(); i++) {
                Card card = player.getHand().getCard(i);
                if (card.toString().equalsIgnoreCase(cardName)) {
                    return card;
                }
            }
        }
        return null;
    }

    /**
     * Plays the game.
     */
    public void playGame() {
        // Setup ability card at the beginning of each game
        setupAbilityCard();
        
        Player player = players.get(0);

        // keep playing until there's a winner
        while (!isDone()) {
            System.out.println("================================");
            System.out.println("Giliran " + player.getName());
            displayPlayerHand(player);
            takeTurn(player);
            player = nextPlayer(player);
        }
        
        System.out.println("== HASIL RONDE " + currentRound + " ==");
        for(int i=0;i<players.size();i++) {
            players.get(i).displayScore();
        }

        System.out.println("Game over!");
        currentRound++;
    }
    
    /**
     * Display specific player's hand
     */
    private void displayPlayerHand(Player player) {
        System.out.print(player.getName() + ": ");
        for (int i = 0; i < player.getHand().size(); i++) {
            System.out.print(player.getHand().getCard(i));
            if (i < player.getHand().size() - 1) {
                System.out.print(" ");
            }
        }
        System.out.println();
    }
    
    /**
     * Get players list for ability card effects
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }

    /**
     * Creates the game and runs it.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Masukkan banyak player");
        int jumlahPlayer = scanner.nextInt();
        scanner.nextLine();

        for(int i=1;i<=jumlahPlayer;i++) {
            scores.add(0);

            System.out.println(i+". Masukkan jenis: Human or AI?");
            String jenisPlayer = scanner.nextLine();

            Player newPlayer = null;

            if(jenisPlayer.equalsIgnoreCase("human")) {
                System.out.println("Masukkan nama player " + (i));
                String nama = scanner.nextLine();
                newPlayer = new HumanPlayer(nama);

            } else if(jenisPlayer.equalsIgnoreCase("ai")) {
                System.out.println("Last or Advanced?");
                String jenisAI = scanner.nextLine();

                if(jenisAI.equalsIgnoreCase("advanced")) {
                    newPlayer = new AIPlayerAdvanced("BOT "+(i)+" ADVANCED");
                } 
                else if(jenisAI.equalsIgnoreCase("last")) {
                    newPlayer = new AIPlayerLast("BOT "+(i)+" LAST");
                } 
            } 

            players.add(newPlayer);
        }
        
        System.out.println("Main berapa kali?");
        int jumlahMain = scanner.nextInt();

        for(int i=1;i<=jumlahMain;i++) {
            System.out.println("=== MEMULAI RONDE " + i + " ===");
            Eights game = new Eights();
            game.currentRound = i;
            game.playGame();

            for(int j=0;j<players.size();j++) {
                scores.set(j, scores.get(j) + game.players.get(j).score());
            }

            System.out.println("~~~~~~~~~~~RONDE "+ i + " SELESAI~~~~~~~~~~~\n\n\n");
        }

        System.out.println("=== SKOR AKHIR ===");
        for(int i=0;i<players.size();i++) {
            System.out.println(players.get(i).getName() + ": " + scores.get(i));
        }
    }
}