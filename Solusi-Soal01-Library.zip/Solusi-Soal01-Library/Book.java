public class Book implements Cloneable{
    private String title;
    private String author;
    private String isbn;
    private boolean isAvailable;
    
    // TODO: Complete the constructor
    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.isAvailable = true;
    }
    
    // TODO: Implement getter methods
    public String getTitle() {
        // Your code here
        return title; // Remove this line and return the title
    }
    
    public String getAuthor() {
        // Your code here
        return author; // Remove this line and return the author
    }
    
    public String getIsbn() {
        // Your code here
        return isbn; // Remove this line and return the isbn
    }
    
    public boolean isAvailable() {
        // Your code here
        return isAvailable; // Remove this line and return the availability status
    }
    
    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }
    
    @Override
    public String toString() {
        return String.format("Book{title='%s', author='%s', isbn='%s', available=%s}", 
                           title, author, isbn, isAvailable);
    }

    @Override
    public boolean equals(Object o){
        if (o!=null && o instanceof Book){
            String otherIsbn = ((Book)o).getIsbn();
            if (isbn!=null && otherIsbn!=null && otherIsbn.equals(isbn)){
                return true;
            }
        }
        return false;
    }

    @Override
    public Object clone(){
        return (Object) new Book(title, author, isbn);
    }

}
