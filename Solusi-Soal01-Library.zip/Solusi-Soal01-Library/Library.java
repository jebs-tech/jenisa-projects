import java.util.*;

public class Library {
    private List<Book> books;
    private List<Member> members;
    
    public Library() {
        // TODO: Initialize the lists
        this.books = new ArrayList<>(); // Remove this line and initialize properly
        this.members = new ArrayList<>(); // Remove this line and initialize properly
    }
    
    public int getBookCount(){
        return books.size();
    }

    public void addBook(Book book) {
        if (book!=null)
            books.add(book);
    }

    public List<Book> getBooks(){
        ArrayList<Book> copiedBoooks = new ArrayList<>();
        for(Book book : books){
            copiedBoooks.add((Book) book.clone());
        }
        return copiedBoooks;
    }

    public int getMemberCount(){
        return members.size();
    }

    public void addMember(Member member) {
        if(member!=null)
            members.add(member);
    }

    public List<Member> getMembers(){
        ArrayList<Member> copiedMembers = new ArrayList<>();
        for(Member member : members){
            copiedMembers.add((Member) member.clone());
        }
        return copiedMembers;    
    }
    
    // TODO: Implement findBookByIsbn method
    public Book findBookByIsbn(String isbn) {
        for (Book book : books){
            if (book.getIsbn().equals(isbn))
                return book;
        }
        // Your code here - use loop to find book with matching ISBN
        return null; // Remove this line and implement the method
    }
    
    // TODO: Implement findMemberById method
    public Member findMemberById(String memberId) {
        for (Member member : members){
            if (member.getMemberId().equals(memberId))
                return member;
        }
        return null; // Remove this line and implement the method
    }
    
    // TODO: Implement borrowBook method
    // Find member and book, then call member's borrowBook method
    public boolean borrowBook(String memberId, String isbn) {
        // Your code here
        Member member = findMemberById(memberId);
        Book book = findBookByIsbn(isbn);
        if (book!= null && member!=null && book.isAvailable()){
            book.setAvailable(false);
            member.addBorrowedBooks(book);
            return true;
        }
        return false; // Remove this line and implement the method
    }
    
    // TODO: Implement returnBook method
    // Find member and book, then call member's returnBook method
    public boolean returnBook(String memberId, String isbn) {
        
        Member member = findMemberById(memberId);
        Book book = findBookByIsbn(isbn);
        if (book!= null && member!=null ){
            if (member.removeBorrowedBook(book)){
                book.setAvailable(true);
                return true;
            }
        }
        return false; // Remove this line and implement the method
    }
    
    public void displayAvailableBooks() {
        System.out.println("Available Books:");
        for (Book book : books) {
            if (book.isAvailable()) {
                System.out.println("- " + book);
            }
        }
    }
}
